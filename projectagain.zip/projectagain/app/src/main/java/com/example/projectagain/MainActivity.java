package com.example.projectagain;

import static com.example.projectagain.R.id.DontAllow;
import static com.example.projectagain.R.id.ok;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText weightGoalEditText, dailyWeightEditText;
    private GridView weightGrid;
    private final DatabaseHelper dbHelper;

    private static final int PERMISSION_REQUEST_CODE = 1;

    private EditText usernameEditText, passwordEditText;

    public MainActivity(DatabaseHelper dbHelper) {
        this.dbHelper = dbHelper;
    }


    @SuppressLint("MissingSuperCall")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameEditText = findViewById(R.id.usernameenterText);
        passwordEditText = findViewById(R.id.editTextTextPassword);
        Button loginButton = findViewById(R.id.loginbutton);
        Button createAccountButton = findViewById(R.id.createaccount);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) Button btnAllow = findViewById(ok); // Permission allow button
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) Button btnDeny = findViewById(DontAllow); // Permission deny button

        // Handle Login Button Click
        loginButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please enter username and password", Toast.LENGTH_SHORT).show();
            } else if (dbHelper.checkUser(username, password)) {
                Toast.makeText(MainActivity.this, "Login Successful!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "Invalid Username or Password", Toast.LENGTH_SHORT).show();
            }
        });

        // Handle Create Account Button Click
        createAccountButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please enter username and password", Toast.LENGTH_SHORT).show();
            } else {
                boolean added = dbHelper.addUser(username, password);
                if (added) {
                    Toast.makeText(MainActivity.this, "Account Created Successfully!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Username already exists!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Handle Permission Buttons
        btnAllow.setOnClickListener(v -> requestPermissions());

        btnDeny.setOnClickListener(v -> Toast.makeText(MainActivity.this, "Permission Denied", Toast.LENGTH_SHORT).show());

        EdgeToEdge.enable(this);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Check permissions at startup
        checkPermissions();
    }

    private void requestPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS, Manifest.permission.READ_PHONE_STATE},
                    PERMISSION_REQUEST_CODE);
        } else {
            Toast.makeText(this, "Permissions Already Granted", Toast.LENGTH_SHORT).show();
        }
    }

    private void checkPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS, Manifest.permission.READ_PHONE_STATE},
                    PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permissions Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permissions Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }



    @SuppressLint({"WrongViewCast", "MissingInflatedId"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.meat);

        weightGoalEditText = findViewById(R.id.weightgoalwhite);
        dailyWeightEditText = findViewById(R.id.Dailyweightwhite);
        FloatingActionButton saveGoalButton = findViewById(R.id.floatingweightbutton);
        FloatingActionButton deleteGoalButton = findViewById(R.id.floatingActionButton4);
        FloatingActionButton saveDailyWeightButton = findViewById(R.id.floatingActionButton3);
        FloatingActionButton deleteDailyWeightButton = findViewById(R.id.floatingActionButton5);
        weightGrid = findViewById(R.id.weightGrid);

        // Load grid data
        loadWeightData();

        saveGoalButton.setOnClickListener(v -> {
            String goalText = weightGoalEditText.getText().toString().trim();
            if (!goalText.isEmpty()) {
                float goalWeight = Float.parseFloat(goalText);
                if (dbHelper.saveGoalWeight(goalWeight)) {
                    Toast.makeText(this, "Goal saved!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        deleteGoalButton.setOnClickListener(v -> {
            if (dbHelper.deleteGoalWeight()) {
                Toast.makeText(this, "Goal deleted!", Toast.LENGTH_SHORT).show();
            }
        });

        saveDailyWeightButton.setOnClickListener(v -> {
            String dailyWeightText = dailyWeightEditText.getText().toString().trim();
            if (!dailyWeightText.isEmpty()) {
                float dailyWeight = Float.parseFloat(dailyWeightText);
                if (dbHelper.saveDailyWeight(dailyWeight)) {
                    Toast.makeText(this, "Weight added!", Toast.LENGTH_SHORT).show();
                    loadWeightData(); // Refresh grid
                }
            }
        });

        deleteDailyWeightButton.setOnClickListener(v -> {
            if (dbHelper.deleteAllDailyWeights()) {
                Toast.makeText(this, "All weights deleted!", Toast.LENGTH_SHORT).show();
                loadWeightData();
            }
        });
    }

    private void loadWeightData() {
        ArrayList<Object> weights = dbHelper.getAllDailyWeights();
        ArrayAdapter<Object> gridAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, weights);
        weightGrid.setAdapter(gridAdapter);
    }
}


